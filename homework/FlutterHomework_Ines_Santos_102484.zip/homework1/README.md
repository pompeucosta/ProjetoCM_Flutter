# Flutter homework

This homework consists of 3 screens from the RunRoute app (Flutter project).
These are the "Session in Progress" screen, which displays a map and statistics from the current run, the "Camera Preview" screen, which allows the user to take photos and the "Photo Taken" screen, for the user to save or discard the photo. All data is currently static except for the session duration.

Dependencies used:
- url_launcher
- flutter_map
- latlong2
- material

To install them run: 
```flutter pub add [package name]```